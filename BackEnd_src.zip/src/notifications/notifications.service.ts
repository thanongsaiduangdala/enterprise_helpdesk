import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Notification, NotificationDocument } from './schemas/notification.schema';
import { NotificationsGateway } from './notifications.gateway';

@Injectable()
export class NotificationsService {
    constructor(
        @InjectModel(Notification.name) private notificationModel: Model<NotificationDocument>,
        private gateway: NotificationsGateway,
    ) { }

    async notify(userId: string, type: string, refId: string, refModel: string, title: string, body: string) {
        const notification = await this.notificationModel.create({ userId, type, refId, refModel, title, body });
        this.gateway.notifyUser(userId, notification);
        return notification;
    }


    findMine(userId: string, unreadOnly = false) {
        const query: any = { userId };
        if (unreadOnly) query.isRead = false;
        return this.notificationModel.find(query).sort({ createdAt: -1 }).exec();
    }


    unreadCount(userId: string) {
        return this.notificationModel.countDocuments({ userId, isRead: false }).exec();
    }

    async markRead(id: string, userId: string) {
        const notification = await this.notificationModel.findById(id).exec();
        if (!notification) throw new NotFoundException('Notification not found');
        if (notification.userId.toString() !== userId) {
            throw new ForbiddenException('You can only mark your own notifications as read');
        }
        notification.isRead = true;
        return notification.save();
    }

    async markAllRead(userId: string) {
        const result = await this.notificationModel.updateMany({ userId, isRead: false }, { isRead: true }).exec();
        return { updated: result.modifiedCount };
    }
}
