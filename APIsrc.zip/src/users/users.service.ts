import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { parse } from 'csv-parse/sync';
import { User, UserDocument } from './schemas/user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { RolesService } from '../roles/roles.service';
import { AuditLogsService } from '../audit-logs/audit-logs.service';
import { MailService } from '../mail/mail.service';
import { SessionsService } from '../sessions/sessions.service';
import { DepartmentsService } from '../departments/departments.service';
import { getEnabledMethods } from '../common/utils/mfa-methods.util';

const SENSITIVE_FIELDS = ['passwordHash', 'password'];

function sanitize(obj: Record<string, any> | null | undefined) {
  if (!obj) return obj;
  const plain = typeof obj.toObject === 'function' ? obj.toObject() : obj;
  const clone = { ...plain };
  for (const field of SENSITIVE_FIELDS) delete clone[field];
  // ຢ່າໃຫ້ secret / PIN hash ຂອງ MFA ຕິດເຂົ້າໄປໃນ audit log
  if (clone.mfa) {
    const { secret, pendingSecret, pinHash, pendingPinHash, ...safeMfa } =
      clone.mfa;
    void secret;
    void pendingSecret;
    void pinHash;
    void pendingPinHash;
    clone.mfa = safeMfa;
  }
  return clone;
}

// ຊື່ role ຂອງຫົວໜ້າພະແນກ (ໃຊ້ແບບດຽວກັບ tickets / dashboard / SLA)
const DEPT_MANAGER_ROLE = 'DEPT_MANAGER';

@Injectable()
export class UsersService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    private rolesService: RolesService,
    private auditLogsService: AuditLogsService,
    private mailService: MailService,
    private sessionsService: SessionsService,
    private departmentsService: DepartmentsService,
  ) {}

  async create(dto: CreateUserDto, actorId: string, ip?: string) {
    const role = await this.rolesService.findOne(dto.role);

    // role DEPT_MANAGER = ເປັນຫົວໜ້າຂອງພະແນກທີ່ເລືອກອັດຕະໂນມັດ (departments.managerIds)
    // ກວດພະແນກກ່ອນສ້າງຜູ້ໃຊ້ — ຫຼີກລ້ຽງສ້າງແລ້ວຈຶ່ງຮູ້ວ່າກຳນົດຫົວໜ້າບໍ່ໄດ້
    const becomesManager = role.name === DEPT_MANAGER_ROLE;
    if (becomesManager) {
      if (!dto.departmentId) {
        throw new BadRequestException(
          `ຜູ້ໃຊ້ role ${DEPT_MANAGER_ROLE} ຕ້ອງເລືອກພະແນກ ເພື່ອເປັນຫົວໜ້າຂອງພະແນກນັ້ນ`,
        );
      }
      await this.departmentsService.findOne(dto.departmentId);
    }

    try {
      const passwordHash = await bcrypt.hash(dto.password, 10);
      const rest: Partial<CreateUserDto> = { ...dto };
      delete rest.password;
      const user = new this.userModel({ ...rest, passwordHash });
      const saved = await user.save();

      await this.auditLogsService.log(
        actorId,
        'USER_CREATED',
        'User',
        saved._id.toString(),
        undefined,
        sanitize(saved),
        ip,
      );

      if (becomesManager && dto.departmentId) {
        await this.departmentsService.setManagerMembership(
          dto.departmentId,
          String(saved._id),
          true,
          actorId,
          ip,
        );
      }

      return saved;
    } catch (error: any) {
      if (error.code === 11000) {
        const field = Object.keys(error.keyPattern || {})[0] || 'field';
        const value = error.keyValue?.[field];
        throw new ConflictException(`${field} "${value}" is already in use`);
      }
      throw error;
    }
  }

  async bulkImport(fileBuffer: Buffer, actorId: string, ip?: string) {
    let rows: Record<string, string>[];
    try {
      rows = parse(fileBuffer, {
        columns: true,
        skip_empty_lines: true,
        trim: true,
      });
    } catch (err: any) {
      throw new ConflictException(`Could not parse CSV file: ${err.message}`);
    }

    const results: Array<{
      row: number;
      email?: string;
      success: boolean;
      error?: string;
    }> = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNumber = i + 2;

      try {
        if (
          !row.email ||
          !row.firstName ||
          !row.lastName ||
          !row.role ||
          !row.branchId ||
          !row.employeeCode
        ) {
          throw new Error(
            'Missing one or more required fields (employeeCode, firstName, lastName, email, role, branchId)',
          );
        }

        const tempPassword = crypto.randomBytes(6).toString('hex');

        const dto: CreateUserDto = {
          employeeCode: row.employeeCode,
          firstName: row.firstName,
          lastName: row.lastName,
          email: row.email,
          password: tempPassword,
          phone: row.phone || undefined,
          role: row.role,
          branchId: row.branchId,
          departmentId: row.departmentId || undefined,
        };

        const user = await this.create(dto, actorId, ip);

        await this.mailService.sendMail(
          user.email,
          'Your Enterprise Helpdesk account has been created',
          `<p>Hi ${user.firstName},</p>
                     <p>An account has been created for you on the Enterprise Helpdesk system.</p>
                     <p>Temporary password: <b>${tempPassword}</b></p>
                     <p>Please log in and change your password as soon as possible.</p>`,
        );

        results.push({ row: rowNumber, email: user.email, success: true });
      } catch (error: any) {
        results.push({
          row: rowNumber,
          email: row.email,
          success: false,
          error: error.message ?? 'Unknown error',
        });
      }
    }

    return {
      total: rows.length,
      created: results.filter((r) => r.success).length,
      failed: results.filter((r) => !r.success).length,
      results,
    };
  }

  findByEmail(email: string) {
    return this.userModel.findOne({ email }).populate('role').exec();
  }

  /** ຄົ້ນຫາດ້ວຍລະຫັດພະນັກງານ (ບໍ່ແຍກຕົວພິມໃຫຍ່/ນ້ອຍ — ໃຫ້ຕົງກັບໜ້າຈໍ) */
  findByEmployeeCode(employeeCode: string) {
    const escaped = (employeeCode || '')
      .trim()
      .replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return this.userModel
      .findOne({ employeeCode: new RegExp(`^${escaped}$`, 'i') })
      .exec();
  }

  /** ຂໍ້ມູນຂັ້ນຕ່ຳເພື່ອໃຫ້ຜູ້ເບີກຈ່າຍກວດຕົວຕົນຜູ້ມາຮັບ (ບໍ່ສົ່ງເບີໂທ/ອີເມວ/ຂໍ້ມູນລະອຽດ) */
  async lookupByEmployeeCode(employeeCode: string) {
    const u = await this.findByEmployeeCode(employeeCode);
    if (!u)
      throw new NotFoundException(`Employee code "${employeeCode}" not found`);
    return {
      _id: String(u._id),
      employeeCode: u.employeeCode,
      firstName: u.firstName,
      lastName: u.lastName,
      departmentId: u.departmentId,
      branchId: u.branchId,
      isActive: u.isActive !== false,
    };
  }

  async setActive(id: string, isActive: boolean, actorId: string, ip?: string) {
    const before = await this.userModel.findById(id).exec();
    if (!before) throw new NotFoundException('User not found');

    const update: any = { isActive };
    if (!isActive) update.deactivatedAt = new Date();
    else update.deactivatedAt = undefined;

    const user = await this.userModel
      .findByIdAndUpdate(id, update, { new: true })
      .exec();
    if (!user) throw new NotFoundException('User not found');

    if (!isActive) {
      await this.sessionsService.revokeAllForUser(id);
    }

    await this.auditLogsService.log(
      actorId,
      isActive ? 'USER_REACTIVATED' : 'USER_DEACTIVATED',
      'User',
      id,
      sanitize(before),
      sanitize(user),
      ip,
    );

    return user;
  }

  findAll(
    filters: { branchId?: string; departmentId?: string; role?: string } = {},
  ) {
    const query: any = {};
    if (filters.branchId) query.branchId = filters.branchId;
    if (filters.departmentId) query.departmentId = filters.departmentId;
    if (filters.role) query.role = filters.role;
    return this.userModel.find(query).populate('role').exec();
  }

  /**
   * ຄົ້ນຫາພະນັກງານທີ່ຍັງໃຊ້ງານ ດ້ວຍຂໍ້ມູນຂັ້ນຕ່ຳ (ລະຫັດ, ຊື່, ແຜນກ) ສຳລັບ picker ເລືອກຜູ້ຮັບແທນ.
   * ບໍ່ສົ່ງ email/ເບີໂທ/ຂໍ້ມູນລະອຽດ. q ແຍກເປັນຄຳ — ທຸກຄຳຕ້ອງກົງກັບ ຊື່/ນາມສະກຸນ/ລະຫັດ.
   */
  async searchForPicker(opts: {
    q?: string;
    departmentId?: string;
    restrictToDepartmentId?: string;
    alsoUserIds?: string[];
    excludeUserIds?: string[];
    limit?: number;
  }) {
    const and: any[] = [{ isActive: { $ne: false } }];
    if (opts.excludeUserIds?.length) {
      and.push({ _id: { $nin: opts.excludeUserIds } });
    }
    if (opts.departmentId) and.push({ departmentId: opts.departmentId });
    if (opts.restrictToDepartmentId) {
      and.push({
        $or: [
          { departmentId: opts.restrictToDepartmentId },
          { _id: { $in: opts.alsoUserIds ?? [] } },
        ],
      });
    }
    const tokens = (opts.q ?? '').trim().split(/\s+/).filter(Boolean).slice(0, 5);
    for (const token of tokens) {
      const re = new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      and.push({
        $or: [{ firstName: re }, { lastName: re }, { employeeCode: re }],
      });
    }
    return this.userModel
      .find({ $and: and })
      .select('employeeCode firstName lastName departmentId')
      .populate('departmentId', 'name')
      .sort({ firstName: 1, lastName: 1 })
      .limit(Math.min(opts.limit ?? 20, 50))
      .lean()
      .exec();
  }

  /** Active users in a branch + department whose role name is in `roleNames` (role populated). */
  async findAssignmentCandidates(
    branchId: string,
    departmentId: string,
    roleNames: string[],
  ) {
    const users = await this.userModel
      .find({ branchId, departmentId, isActive: true })
      .populate('role')
      .exec();
    return users.filter((u: any) => roleNames.includes(u.role?.name));
  }

  findActiveByBranch(branchId: string) {
    return this.userModel.find({ branchId, isActive: true }).exec();
  }

  findActiveByDepartment(departmentId: string) {
    return this.userModel.find({ departmentId, isActive: true }).exec();
  }

  findAllActive() {
    return this.userModel.find({ isActive: true }).exec();
  }

  /** ລະຫັດຜູ້ໃຊ້ທີ່ຍັງໃຊ້ງານ ແລະ ມີສິດ module:action (ລວມ SUPER_ADMIN) — ໃຊ້ສົ່ງແຈ້ງເຕືອນຜູ້ອະນຸມັດ */
  async findActiveIdsWithPermission(module: string, action: string) {
    const roles = await this.rolesService.findRolesWithPermission(module, action);
    const roleIds = new Set(roles.map((r) => String(r._id)));
    const superAdmin = await this.rolesService.findByName('SUPER_ADMIN');
    if (superAdmin) roleIds.add(String(superAdmin._id));
    if (roleIds.size === 0) return [] as string[];
    const users = await this.findActiveByRoleIds([...roleIds]);
    return users.map((u) => String(u._id));
  }

  findActiveByRoleIds(roleIds: string[]) {
    return this.userModel
      .find({ role: { $in: roleIds }, isActive: true })
      .exec();
  }

  async findOne(id: string) {
    const user = await this.userModel
      .findById(id)
      .populate('role')
      .populate('departmentId')
      .exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async update(id: string, dto: UpdateUserDto, actorId: string, ip?: string) {
    const newRole = dto.role
      ? await this.rolesService.findOne(dto.role)
      : undefined;

    const before = await this.userModel.findById(id).populate('role').exec();
    if (!before) throw new NotFoundException('User not found');

    // role DEPT_MANAGER ⇔ ເປັນຫົວໜ້າຂອງພະແນກຂອງຕົນ (departments.managerIds) — ຊິງກ໌ທຸກຄັ້ງທີ່ບັນທຶກ
    const wasManager = (before.role as any)?.name === DEPT_MANAGER_ROLE;
    const willBeManager = (newRole ? newRole.name : (before.role as any)?.name) === DEPT_MANAGER_ROLE;
    const oldDepartmentId = before.departmentId;
    const targetDepartmentId =
      dto.departmentId !== undefined ? dto.departmentId : before.departmentId;
    if (
      willBeManager &&
      (dto.role !== undefined || dto.departmentId !== undefined)
    ) {
      if (!targetDepartmentId) {
        throw new BadRequestException(
          `ຜູ້ໃຊ້ role ${DEPT_MANAGER_ROLE} ຕ້ອງເລືອກພະແນກ ເພື່ອເປັນຫົວໜ້າຂອງພະແນກນັ້ນ`,
        );
      }
      await this.departmentsService.findOne(targetDepartmentId);
    }

    const user = await this.userModel
      .findByIdAndUpdate(id, dto, { new: true })
      .populate('role')
      .exec();
    if (!user) throw new NotFoundException('User not found');

    const action =
      dto.role && dto.role !== (before.role as any)?._id?.toString()
        ? 'USER_ROLE_CHANGED'
        : 'USER_UPDATED';

    await this.auditLogsService.log(
      actorId,
      action,
      'User',
      id,
      sanitize(before),
      sanitize(user),
      ip,
    );

    // ເຊົາເປັນຫົວໜ້າ (ປ່ຽນ role ອອກ ຫຼື ຍ້າຍພະແນກ) → ເອົາອອກຈາກພະແນກເກົ່າ
    if (
      wasManager &&
      oldDepartmentId &&
      (!willBeManager || oldDepartmentId !== targetDepartmentId)
    ) {
      await this.departmentsService.setManagerMembership(
        oldDepartmentId,
        id,
        false,
        actorId,
        ip,
      );
    }
    // ເປັນຫົວໜ້າ → ໃຫ້ຢູ່ໃນ managerIds ຂອງພະແນກປັດຈຸບັນ (ແກ້ບັນຊີເກົ່າທີ່ຍັງບໍ່ຖືກເພີ່ມນຳ)
    if (willBeManager && targetDepartmentId) {
      await this.departmentsService.setManagerMembership(
        targetDepartmentId,
        id,
        true,
        actorId,
        ip,
      );
    }

    return user;
  }

  async setMfaSecret(id: string, secret: string) {
    const user = await this.userModel
      .findByIdAndUpdate(id, { 'mfa.secret': secret }, { new: true })
      .exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async setPendingMfaSecret(id: string, secret: string) {
    const user = await this.userModel
      .findByIdAndUpdate(
        id,
        {
          $set: { 'mfa.pendingSecret': secret, 'mfa.pendingMethod': 'totp' },
          $unset: { 'mfa.pendingPinHash': '' },
        },
        { new: true },
      )
      .exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async setPendingMfaMethod(id: string, method: string) {
    const user = await this.userModel
      .findByIdAndUpdate(
        id,
        {
          'mfa.pendingMethod': method,
          $unset: { 'mfa.pendingSecret': '', 'mfa.pendingPinHash': '' },
        },
        { new: true },
      )
      .exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async setPendingMfaPin(id: string, pinHash: string) {
    const user = await this.userModel
      .findByIdAndUpdate(
        id,
        {
          $set: { 'mfa.pendingPinHash': pinHash, 'mfa.pendingMethod': 'pin' },
          $unset: { 'mfa.pendingSecret': '' },
        },
        { new: true },
      )
      .exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  // ເພີ່ມວິທີທີ່ pending ເຂົ້າໃນລາຍການ methods (ບໍ່ລຶບວິທີອື່ນທີ່ເປີດຢູ່ແລ້ວ)
  async confirmMfaEnabled(id: string) {
    const user = await this.userModel.findById(id).exec();
    if (!user) throw new NotFoundException('User not found');

    const method = user.mfa?.pendingMethod;
    if (!method) {
      throw new NotFoundException('No pending MFA setup to confirm');
    }

    const current = getEnabledMethods(user.mfa);
    const methods = current.includes(method as any)
      ? current
      : [...current, method as any];

    const set: Record<string, any> = {
      'mfa.enabled': true,
      'mfa.methods': methods,
      'mfa.method': methods[0],
    };
    const unset: Record<string, ''> = { 'mfa.pendingMethod': '' };

    if (method === 'totp') {
      if (!user.mfa?.pendingSecret) {
        throw new NotFoundException('No pending MFA secret to confirm');
      }
      set['mfa.secret'] = user.mfa.pendingSecret;
      unset['mfa.pendingSecret'] = '';
    }

    if (method === 'pin') {
      if (!user.mfa?.pendingPinHash) {
        throw new NotFoundException('No pending PIN to confirm');
      }
      set['mfa.pinHash'] = user.mfa.pendingPinHash;
      unset['mfa.pendingPinHash'] = '';
    }

    const updated = await this.userModel
      .findByIdAndUpdate(id, { $set: set, $unset: unset }, { new: true })
      .exec();
    if (!updated) throw new NotFoundException('User not found');
    return updated;
  }

  // ປິດວິທີ MFA ໜຶ່ງວິທີ (ວິທີອື່ນຍັງເປີດຢູ່ຕາມເດີມ)
  async removeMfaMethod(id: string, method: string) {
    const user = await this.userModel.findById(id).exec();
    if (!user) throw new NotFoundException('User not found');

    const current = getEnabledMethods(user.mfa);
    if (!current.includes(method as any)) {
      throw new BadRequestException('This MFA method is not enabled');
    }
    const methods = current.filter((m) => m !== method);

    const set: Record<string, any> = {
      'mfa.enabled': methods.length > 0,
      'mfa.methods': methods,
    };
    const unset: Record<string, ''> = {};
    if (methods.length > 0) set['mfa.method'] = methods[0];
    else unset['mfa.method'] = '';

    if (method === 'totp') {
      unset['mfa.secret'] = '';
      unset['mfa.pendingSecret'] = '';
    }
    if (method === 'pin') {
      unset['mfa.pinHash'] = '';
      unset['mfa.pendingPinHash'] = '';
    }
    if (user.mfa?.pendingMethod === method) unset['mfa.pendingMethod'] = '';

    const update: Record<string, any> = { $set: set };
    if (Object.keys(unset).length > 0) update.$unset = unset;

    const updated = await this.userModel
      .findByIdAndUpdate(id, update, { new: true })
      .exec();
    if (!updated) throw new NotFoundException('User not found');
    return updated;
  }

  async setPasswordHash(id: string, passwordHash: string) {
    const updated = await this.userModel
      .findByIdAndUpdate(id, { $set: { passwordHash } })
      .exec();
    if (!updated) throw new NotFoundException('User not found');
  }

  async recordLoginFailure(id: string, maxAttempts: number, lockMs: number) {
    // $inc ແບບ atomic — ບໍ່ໃຫ້ການ login ພ້ອມກັນຂຽນທັບກັນ (read-modify-write ແບບເກົ່າສູນເສຍການນັບ)
    const user = await this.userModel
      .findByIdAndUpdate(
        id,
        { $inc: { failedLoginAttempts: 1 } },
        { new: true },
      )
      .exec();
    if (!user) return { locked: false, attempts: 0 };
    const attempts = user.failedLoginAttempts ?? 0;
    if (attempts >= maxAttempts) {
      await this.userModel
        .findByIdAndUpdate(id, {
          $set: {
            failedLoginAttempts: 0,
            lockedUntil: new Date(Date.now() + lockMs),
          },
        })
        .exec();
      return { locked: true, attempts };
    }
    return { locked: false, attempts };
  }

  /** ປົດລັອກບັນຊີດ້ວຍຜູ້ດູແລ (ລຶບການນັບຜິດ ແລະ ເວລາລັອກ) */
  async unlock(id: string, actorId: string, ip?: string) {
    const before = await this.userModel.findById(id).exec();
    if (!before) throw new NotFoundException('User not found');

    const updated = await this.userModel
      .findByIdAndUpdate(
        id,
        { $set: { failedLoginAttempts: 0 }, $unset: { lockedUntil: '' } },
        { new: true },
      )
      .exec();
    if (!updated) throw new NotFoundException('User not found');

    await this.auditLogsService.log(
      actorId,
      'USER_UNLOCKED',
      'User',
      id,
      {
        lockedUntil: before.lockedUntil,
        failedLoginAttempts: before.failedLoginAttempts,
      },
      { lockedUntil: null, failedLoginAttempts: 0 },
      ip,
    );
    return updated;
  }

  async recordLoginSuccess(id: string) {
    await this.userModel
      .findByIdAndUpdate(id, {
        $set: { lastLoginAt: new Date(), failedLoginAttempts: 0 },
        $unset: { lockedUntil: '' },
      })
      .exec();
  }

  async findOneRaw(id: string) {
    const user = await this.userModel.findById(id).exec();
    if (!user) throw new NotFoundException('User not found');
    return user;
  }

  async remove(id: string, actorId: string, ip?: string) {
    const before = await this.userModel.findById(id).exec();
    if (!before) throw new NotFoundException('User not found');

    const result = await this.userModel.findByIdAndDelete(id).exec();
    if (!result) throw new NotFoundException('User not found');

    await this.sessionsService.revokeAllForUser(id);

    await this.auditLogsService.log(
      actorId,
      'USER_DELETED',
      'User',
      id,
      sanitize(before),
      undefined,
      ip,
    );

    return result;
  }
}
