import { Body, Controller, Get, HttpCode, Param, Post } from '@nestjs/common';
import { Throttle } from '@nestjs/throttler';
import { RoomInvitesService } from './room-invites.service';
import { JoinDto } from './dto/invite.dto';

// ສາທາລະນະ — ແຂກສະແກນ QR ແລ້ວເຂົ້າໜ້ານີ້ໂດຍບໍ່ຕ້ອງ login. ບໍ່ມີ JwtAuthGuard ຕັ້ງໃຈ.
// ຄວາມປອດໄພມາຈາກ token ທີ່ເດົາບໍ່ໄດ້ (144 bit) + ກວດລາຍຊື່ໃນ service + rate limit ເຂັ້ມກວ່າປົກກະຕິ
@Controller('join')
@Throttle({ default: { limit: 30, ttl: 60000 } })
export class RoomJoinController {
    constructor(private invites: RoomInvitesService) { }

    @Get(':token')
    info(@Param('token') token: string) {
        return this.invites.joinInfo(token);
    }

    @Post(':token')
    @HttpCode(200)
    join(@Param('token') token: string, @Body() dto: JoinDto) {
        return this.invites.join(token, dto);
    }
}
