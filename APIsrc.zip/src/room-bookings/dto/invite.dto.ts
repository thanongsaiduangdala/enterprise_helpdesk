import { IsEmail, IsEnum, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { InviteMode } from '../schemas/room-booking.schema';

export class SetInviteModeDto {
    @ApiProperty({ enum: [...Object.values(InviteMode), 'NONE'], example: 'PRIVATE' })
    @IsEnum({ ...InviteMode, NONE: 'NONE' })
    mode!: InviteMode | 'NONE';
}

export class AddInviteeDto {
    @ApiProperty({ example: 'Somchai V.' })
    @IsNotEmpty()
    @IsString()
    @MaxLength(80)
    name!: string;

    @ApiPropertyOptional({ example: 'somchai@example.com' })
    @IsOptional()
    @IsEmail()
    @MaxLength(120)
    email?: string;

    @ApiPropertyOptional({ example: '020 5555 1234' })
    @IsOptional()
    @IsString()
    @MaxLength(30)
    phone?: string;
}

// ຂໍ້ມູນທີ່ແຂກກອກຕອນສະແກນ QR ປະຕູ (ໜ້າ /join/:token — ບໍ່ຕ້ອງ login)
export class JoinDto {
    @IsOptional()
    @IsString()
    @MaxLength(80)
    name?: string;

    // ອີເມວ ຫຼື ເບີໂທ — ໃຊ້ຢືນຢັນຕົວຕົນໃນໂໝດ PRIVATE ເມື່ອສະແກນ QR ກາງ
    @IsOptional()
    @IsString()
    @MaxLength(120)
    contact?: string;
}
