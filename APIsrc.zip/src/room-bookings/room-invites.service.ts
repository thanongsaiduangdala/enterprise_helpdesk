import {
    BadRequestException,
    ConflictException,
    ForbiddenException,
    forwardRef,
    Inject,
    Injectable,
    NotFoundException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { randomBytes } from 'crypto';
import { Model, Types } from 'mongoose';
import {
    BookingCheckIn,
    BookingInvitee,
    BookingStatus,
    InviteMode,
    RoomBooking,
    RoomBookingDocument,
} from './schemas/room-booking.schema';
import { AddInviteeDto, JoinDto, SetInviteModeDto } from './dto/invite.dto';
import { RoomsService } from '../rooms/rooms.service';
import { RoomBookingsGateway } from './room-bookings.gateway';
import { hasAnyPermission, PermissionUser } from '../common/utils/permission.util';
import { toCsv } from '../reports/csv.util';
import { AttendanceRow, buildAttendancePdf, buildQrPdf, fmtDateTime, QrPageInput } from './room-invites.pdf';

// ອະນຸຍາດໃຫ້ແຂກສະແກນກ່ອນເວລານັດໄດ້ຈັກນາທີ
const EARLY_JOIN_MINUTES = 30;
const MAX_INVITEES = 300;
const MAX_DENIED_LOGS = 200;
const HARD_MAX_ADMITTED = 500; // ກັນ document ໃຫຍ່ເກີນໄປ

export type JoinReason =
    | 'INVALID_QR'
    | 'BOOKING_NOT_ACTIVE'
    | 'INVITES_CLOSED'
    | 'TOO_EARLY'
    | 'ENDED'
    | 'NOT_ON_LIST'
    | 'REVOKED'
    | 'ROOM_FULL';

const REASON_TEXT: Record<JoinReason, string> = {
    INVALID_QR: 'This QR code is not valid.',
    BOOKING_NOT_ACTIVE: 'This booking is cancelled or not confirmed.',
    INVITES_CLOSED: 'The host has closed invitations for this meeting.',
    TOO_EARLY: 'The meeting has not opened for check-in yet.',
    ENDED: 'This meeting has ended.',
    NOT_ON_LIST: 'You are not on the guest list.',
    REVOKED: 'Your invitation was removed by the host.',
    ROOM_FULL: 'The room is full.',
};

export interface JoinBookingInfo {
    title: string;
    roomName: string;
    startAt: Date;
    endAt: Date;
}

type Via = 'DOOR_QR' | 'PERSONAL_QR';
type HostUser = PermissionUser & { userId: string };

const newToken = () => randomBytes(18).toString('base64url'); // 144 bit, 24 ຕົວອັກສອນ

const cleanName = (v?: string) =>
    (v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);

// ອີເມວ -> lowercase; ເບີໂທ -> ເອົາຊ່ອງຫວ່າງ/ຂີດ/ວົງເລັບອອກ
const normContact = (v?: string) => (v ?? '').trim().toLowerCase().replace(/[\s\-()]/g, '');
const normName = (v?: string) => cleanName(v).toLowerCase();

// ກັນ CSV/Excel formula injection — ຊື່ທີ່ແຂກກອກເອງ (PUBLIC) ເປັນຂໍ້ມູນທີ່ເຊື່ອບໍ່ໄດ້
const safeCell = (v: any) => {
    const s = v === null || v === undefined ? '' : String(v);
    return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
};

@Injectable()
export class RoomInvitesService {
    constructor(
        @InjectModel(RoomBooking.name) private bookingModel: Model<RoomBookingDocument>,
        @Inject(forwardRef(() => RoomsService)) private roomsService: RoomsService,
        private gateway: RoomBookingsGateway,
    ) { }

    // ───────────────────────── helpers ─────────────────────────

    // ໂຫຼດ booking ພ້ອມ field ລັບ (token / invitees / checkIns ຖືກ select:false ໄວ້ຢູ່ schema)
    // ໃຊ້ຮູບແບບດຽວກັບ RoomBookingsService.findOne ເພື່ອຮອງຮັບ _id ເກົ່າທີ່ເປັນ ObjectId
    private async load(id: string) {
        const booking = await this.bookingModel
            .findOne({ $expr: { $eq: [{ $toString: '$_id' }, id] } })
            .select('+inviteToken +invitees +checkIns')
            .exec();
        if (!booking) throw new NotFoundException('Booking not found');
        if (!Array.isArray(booking.invitees)) booking.invitees = [];
        if (!Array.isArray(booking.checkIns)) booking.checkIns = [];
        return booking;
    }

    private assertHost(booking: RoomBookingDocument, user: HostUser) {
        const isOwner = booking.bookedBy.toString() === user.userId;
        const elevated = hasAnyPermission(user, 'rooms', ['manage', 'approve']);
        if (!isOwner && !elevated) {
            throw new ForbiddenException('Only the person who booked this room can manage its invitations');
        }
    }

    private async roomInfo(roomId: string): Promise<{ name: string; capacity?: number }> {
        try {
            const room: any = await this.roomsService.findOne(roomId);
            return { name: room?.name || roomId, capacity: room?.capacity };
        } catch {
            return { name: roomId };
        }
    }

    private async bookingInfo(booking: RoomBookingDocument): Promise<JoinBookingInfo & { capacity?: number }> {
        const room = await this.roomInfo(String(booking.roomId));
        return { title: booking.title, roomName: room.name, startAt: booking.startAt, endAt: booking.endAt, capacity: room.capacity };
    }

    private appBaseUrl(requested?: string): string {
        const allowed = (process.env.FRONTEND_URLS || 'http://localhost:5173')
            .split(',')
            .map((s) => s.trim().replace(/\/+$/, ''))
            .filter(Boolean);
        const wanted = requested?.trim().replace(/\/+$/, '');
        // baseUrl ຈາກ client ໃຊ້ໄດ້ສະເພາະ origin ທີ່ຢູ່ໃນ FRONTEND_URLS — ກັນບໍ່ໃຫ້ QR ຊີ້ໄປເວັບອື່ນ
        if (wanted && allowed.includes(wanted)) return wanted;
        return (process.env.PUBLIC_APP_URL || allowed[0]).replace(/\/+$/, '');
    }

    private joinUrl(token: string, baseUrl?: string) {
        return `${this.appBaseUrl(baseUrl)}/join/${token}`;
    }

    // ───────────────────────── host: manage ─────────────────────────

    async getInvite(id: string, user: HostUser) {
        const b = await this.load(id);
        this.assertHost(b, user);

        const active = b.invitees.filter((i) => !i.revokedAt);
        const admitted = b.checkIns.filter((c) => c.result === 'ADMITTED');
        const denied = b.checkIns.filter((c) => c.result === 'DENIED');

        return {
            bookingId: b._id,
            title: b.title,
            status: b.status,
            startAt: b.startAt,
            endAt: b.endAt,
            inviteMode: b.inviteMode ?? null,
            invitees: active.map((i) => ({
                _id: String(i._id),
                name: i.name,
                email: i.email ?? null,
                phone: i.phone ?? null,
                addedAt: i.addedAt,
                joinedAt: i.joinedAt ?? null,
            })),
            stats: {
                invited: active.length,
                joined: admitted.length,
                notJoined: active.filter((i) => !i.joinedAt).length,
                denied: denied.length,
            },
            recentScans: [...b.checkIns].reverse().slice(0, 50).map((c) => ({
                name: c.name,
                contact: c.contact ?? null,
                result: c.result,
                reason: c.reason ?? null,
                via: c.via,
                at: c.at,
            })),
        };
    }

    async setMode(id: string, user: HostUser, dto: SetInviteModeDto) {
        const b = await this.load(id);
        this.assertHost(b, user);

        if (dto.mode === 'NONE') {
            await this.bookingModel.updateOne({ _id: b._id }, { $unset: { inviteMode: 1 } });
        } else {
            if (b.status !== BookingStatus.CONFIRMED) {
                throw new BadRequestException('Invitations can only be opened on a confirmed booking');
            }
            if (b.endAt.getTime() <= Date.now()) {
                throw new BadRequestException('This booking has already ended');
            }
            const $set: Record<string, any> = { inviteMode: dto.mode };
            if (!b.inviteToken) $set.inviteToken = newToken();
            await this.bookingModel.updateOne({ _id: b._id }, { $set });
        }
        this.gateway.emitBookingsChanged(String(b.roomId));
        return this.getInvite(id, user);
    }

    async addInvitee(id: string, user: HostUser, dto: AddInviteeDto) {
        const b = await this.load(id);
        this.assertHost(b, user);
        if (b.inviteMode !== InviteMode.PRIVATE) {
            throw new BadRequestException('Switch the booking to PRIVATE to build a guest list');
        }
        if (b.endAt.getTime() <= Date.now()) throw new BadRequestException('This booking has already ended');

        const name = cleanName(dto.name);
        if (!name) throw new BadRequestException('Name is required');
        const email = dto.email?.trim().toLowerCase() || undefined;
        const phone = dto.phone?.trim() || undefined;

        const active = b.invitees.filter((i) => !i.revokedAt);
        if (active.length >= MAX_INVITEES) throw new BadRequestException(`Guest list is limited to ${MAX_INVITEES} people`);
        const dup = active.find(
            (i) =>
                (email && i.email === email) ||
                (phone && i.phone && normContact(i.phone) === normContact(phone)) ||
                (!email && !phone && !i.email && !i.phone && normName(i.name) === normName(name)),
        );
        if (dup) throw new ConflictException(`"${dup.name}" is already on the guest list`);

        const invitee = { _id: new Types.ObjectId(), name, email, phone, token: newToken(), addedAt: new Date() };
        await this.bookingModel.updateOne({ _id: b._id }, { $push: { invitees: invitee } });
        return { _id: String(invitee._id), name, email: email ?? null, phone: phone ?? null };
    }

    async removeInvitee(id: string, user: HostUser, inviteeId: string) {
        const b = await this.load(id);
        this.assertHost(b, user);
        if (!Types.ObjectId.isValid(inviteeId)) throw new BadRequestException('Invalid invitee id');
        const oid = new Types.ObjectId(inviteeId);
        const res = await this.bookingModel.updateOne(
            { _id: b._id, invitees: { $elemMatch: { _id: oid, revokedAt: { $exists: false } } } },
            { $set: { 'invitees.$.revokedAt': new Date() } },
        );
        if (!res.matchedCount) throw new NotFoundException('Invitee not found');
        return { removed: true };
    }

    // ───────────────────────── host: PDFs ─────────────────────────

    // target = 'door' -> QR ກາງ; ບໍ່ໃສ່ -> PUBLIC: QR ກາງ, PRIVATE: pass ສ່ວນຕົວ (ທຸກຄົນ ຫຼື inviteeId ດຽວ)
    async buildQrPdf(id: string, user: HostUser, opts: { inviteeId?: string; target?: string; baseUrl?: string }) {
        const b = await this.load(id);
        this.assertHost(b, user);
        if (!b.inviteMode || !b.inviteToken) {
            throw new BadRequestException('Open invitations (Private or Public) before printing a QR code');
        }
        const info = await this.bookingInfo(b);
        const base = { bookingTitle: info.title, roomName: info.roomName, startAt: info.startAt, endAt: info.endAt, mode: b.inviteMode } as const;

        const pages: QrPageInput[] = [];
        if (b.inviteMode === InviteMode.PUBLIC || opts.target === 'door') {
            pages.push({ ...base, url: this.joinUrl(b.inviteToken, opts.baseUrl) });
        } else {
            let list = b.invitees.filter((i) => !i.revokedAt);
            if (opts.inviteeId) {
                list = list.filter((i) => String(i._id) === opts.inviteeId);
                if (!list.length) throw new NotFoundException('Invitee not found');
            }
            if (!list.length) throw new BadRequestException('Add at least one guest before printing passes');
            for (const i of list) pages.push({ ...base, url: this.joinUrl(i.token, opts.baseUrl), guestName: i.name });
        }
        return buildQrPdf(pages);
    }

    // ───────────────────────── host: attendance report ─────────────────────────

    private async attendanceRows(b: RoomBookingDocument) {
        const rows: (AttendanceRow & { method: string })[] = [];
        const joinedEntries = b.checkIns.filter((c) => c.result === 'ADMITTED');
        const via = (c?: BookingCheckIn) => (c ? (c.via === 'PERSONAL_QR' ? 'Personal QR' : 'Door QR') : '');

        if (b.inviteMode === InviteMode.PRIVATE || b.invitees.length) {
            for (const i of b.invitees) {
                if (i.revokedAt && !i.joinedAt) continue;
                const entry = joinedEntries.find((c) => c.inviteeId === String(i._id));
                rows.push({
                    name: i.name,
                    contact: [i.email, i.phone].filter(Boolean).join(' / '),
                    status: i.joinedAt ? 'JOINED' : 'NOT_JOINED',
                    time: i.joinedAt ? fmtDateTime(i.joinedAt) : '',
                    method: i.joinedAt ? via(entry) : '',
                    note: i.revokedAt ? 'Removed from list after joining' : '',
                });
            }
        }
        // ຄົນທີ່ເຂົ້າຜ່ານ QR ກາງແບບ PUBLIC (ບໍ່ມີ inviteeId)
        for (const c of joinedEntries.filter((c) => !c.inviteeId)) {
            rows.push({ name: c.name, contact: c.contact ?? '', status: 'JOINED', time: fmtDateTime(c.at), method: via(c), note: '' });
        }
        for (const c of b.checkIns.filter((c) => c.result === 'DENIED')) {
            rows.push({
                name: c.name,
                contact: c.contact ?? '',
                status: 'DENIED',
                time: fmtDateTime(c.at),
                method: via(c),
                note: REASON_TEXT[c.reason as JoinReason] ?? c.reason ?? '',
            });
        }
        const order: Record<string, number> = { JOINED: 0, NOT_JOINED: 1, DENIED: 2 };
        rows.sort((a, b2) => order[a.status] - order[b2.status]);
        return rows;
    }

    async buildCsv(id: string, user: HostUser) {
        const b = await this.load(id);
        this.assertHost(b, user);
        const info = await this.bookingInfo(b);
        const rows = await this.attendanceRows(b);

        const header = ['Booking ID', 'Title', 'Room', 'Mode', 'Name', 'Contact', 'Status', 'Time', 'Method', 'Note'];
        const data = rows.map((r) => ({
            'Booking ID': b._id,
            Title: safeCell(info.title),
            Room: safeCell(info.roomName),
            Mode: b.inviteMode ?? '',
            Name: safeCell(r.name),
            Contact: safeCell(r.contact),
            Status: r.status,
            Time: r.time,
            Method: r.method,
            Note: safeCell(r.note),
        }));
        const csv = data.length ? toCsv(data) : header.join(',');
        return { csv: '\uFEFF' + csv, filename: `attendance-${b._id}.csv` }; // BOM ເພື່ອໃຫ້ Excel ອ່ານ UTF-8 (ລາວ) ຖືກ
    }

    async buildReportPdf(id: string, user: HostUser) {
        const b = await this.load(id);
        this.assertHost(b, user);
        const info = await this.bookingInfo(b);
        const rows = await this.attendanceRows(b);
        const count = (s: string) => rows.filter((r) => r.status === s).length;
        const pdfRows = rows.map(({ method, note, ...r }) => ({ ...r, note: [method, note].filter(Boolean).join(' · ') }));
        const pdf = await buildAttendancePdf({
            bookingId: String(b._id),
            bookingTitle: info.title,
            roomName: info.roomName,
            mode: b.inviteMode ?? 'NOT OPENED',
            startAt: b.startAt,
            endAt: b.endAt,
            invited: b.invitees.filter((i) => !i.revokedAt).length,
            joined: count('JOINED'),
            notJoined: count('NOT_JOINED'),
            denied: count('DENIED'),
            rows: pdfRows,
        });
        return { pdf, filename: `attendance-${b._id}.pdf` };
    }

    // ───────────────────────── guest: scan QR (no login) ─────────────────────────

    private async findByToken(token: string): Promise<{ booking: RoomBookingDocument; invitee?: BookingInvitee; via: Via } | null> {
        if (!/^[A-Za-z0-9_-]{16,64}$/.test(token || '')) return null;
        const door = await this.bookingModel.findOne({ inviteToken: token }).select('+inviteToken +invitees +checkIns').exec();
        if (door) return { booking: door, via: 'DOOR_QR' };
        const pass = await this.bookingModel.findOne({ 'invitees.token': token }).select('+inviteToken +invitees +checkIns').exec();
        if (!pass) return null;
        const invitee = pass.invitees.find((i) => i.token === token);
        return invitee ? { booking: pass, invitee, via: 'PERSONAL_QR' } : null;
    }

    // ໃຫ້ໜ້າ /join/:token ຮູ້ວ່າຈະຖາມຫຍັງແຂກກ່ອນ (ຊື່ / ອີເມວ-ເບີໂທ) — ບໍ່ບັນທຶກຫຍັງ
    async joinInfo(token: string) {
        const found = await this.findByToken(token);
        if (!found) return { valid: false };
        const { booking, invitee, via } = found;
        const info = await this.bookingInfo(booking);
        return {
            valid: true,
            via,
            mode: booking.inviteMode ?? null,
            guestName: invitee?.name ?? null,
            needsName: !invitee,
            needsContact: !invitee && booking.inviteMode === InviteMode.PRIVATE,
            title: info.title,
            roomName: info.roomName,
            startAt: info.startAt,
            endAt: info.endAt,
        };
    }

    async join(token: string, dto: JoinDto) {
        const found = await this.findByToken(token);
        if (!found) return { result: 'DENIED', reason: 'INVALID_QR', message: REASON_TEXT.INVALID_QR };

        const { booking, via } = found;
        let invitee = found.invitee;
        const info = await this.bookingInfo(booking);
        const publicInfo: JoinBookingInfo = { title: info.title, roomName: info.roomName, startAt: info.startAt, endAt: info.endAt };

        const typedName = cleanName(dto.name);
        const typedContact = (dto.contact ?? '').trim().slice(0, 120);
        const ctx = () => ({
            name: invitee ? invitee.name : typedName,
            contact: invitee ? [invitee.email, invitee.phone].filter(Boolean).join(' / ') : typedContact,
        });
        const deny = async (reason: JoinReason) => {
            const c = ctx();
            await this.logDenied(booking, { ...c, inviteeId: invitee ? String(invitee._id) : undefined, reason, via });
            return { result: 'DENIED', reason, message: REASON_TEXT[reason], name: c.name || null, booking: publicInfo };
        };
        const needInfo = () => ({
            result: 'NEEDS_INFO',
            needsContact: booking.inviteMode === InviteMode.PRIVATE,
            mode: booking.inviteMode,
            booking: publicInfo,
        });

        // 1) ສະຖານະຂອງ booking / ເວລາ
        const now = Date.now();
        if (booking.status !== BookingStatus.CONFIRMED) return deny('BOOKING_NOT_ACTIVE');
        if (!booking.inviteMode) return deny('INVITES_CLOSED');
        if (now < booking.startAt.getTime() - EARLY_JOIN_MINUTES * 60000) return deny('TOO_EARLY');
        if (now >= booking.endAt.getTime() || booking.checkedOutAt) return deny('ENDED');

        // 2) ຢືນຢັນຕົວຕົນ
        if (invitee) {
            if (invitee.revokedAt) return deny('REVOKED');
        } else if (booking.inviteMode === InviteMode.PRIVATE) {
            // QR ກາງໃນໂໝດ PRIVATE: ຕ້ອງຊື່ກົງກັບລາຍຊື່ ແລະ ຖ້າແຂກມີອີເມວ/ເບີໂທໄວ້ ຕ້ອງກົງກັນດ້ວຍ (ກັນການເດົາຊື່)
            if (!typedName || !typedContact) return needInfo();
            const contact = normContact(typedContact);
            const match = booking.invitees.find((i) => {
                if (i.revokedAt || normName(i.name) !== normName(typedName)) return false;
                const onFile = [i.email, i.phone].filter(Boolean).map((v) => normContact(v));
                return onFile.length === 0 || onFile.includes(contact);
            });
            if (!match) return deny('NOT_ON_LIST');
            invitee = match;
        } else {
            // PUBLIC: ໃຜກໍເຂົ້າໄດ້ ແຕ່ຕ້ອງບອກຊື່ ເພື່ອບັນທຶກລາຍງານ
            if (!typedName) return needInfo();
            const admitted = booking.checkIns.filter((c) => c.result === 'ADMITTED').length;
            const limit = Math.min(info.capacity && info.capacity > 0 ? info.capacity : HARD_MAX_ADMITTED, HARD_MAX_ADMITTED);
            const already = booking.checkIns.some(
                (c) => c.result === 'ADMITTED' && normName(c.name) === normName(typedName) && normContact(c.contact) === normContact(typedContact),
            );
            if (!already && admitted >= limit) return deny('ROOM_FULL');
        }

        // 3) ອະນຸຍາດເຂົ້າ
        const c = ctx();
        const entry = { name: c.name, contact: c.contact || undefined, inviteeId: invitee ? String(invitee._id) : undefined, result: 'ADMITTED' as const, via, at: new Date() };
        let alreadyJoined = false;

        if (invitee) {
            if (invitee.joinedAt) {
                alreadyJoined = true;
            } else {
                const res = await this.bookingModel.updateOne(
                    { _id: booking._id, invitees: { $elemMatch: { _id: invitee._id, joinedAt: { $exists: false } } } },
                    { $set: { 'invitees.$.joinedAt': entry.at }, $push: { checkIns: entry }, $addToSet: { attendees: c.name } },
                );
                alreadyJoined = !res.modifiedCount; // ມີຄົນສະແກນພ້ອມກັນ — ຖືວ່າເຂົ້າແລ້ວ
            }
        } else {
            alreadyJoined = booking.checkIns.some(
                (x) => x.result === 'ADMITTED' && !x.inviteeId && normName(x.name) === normName(c.name) && normContact(x.contact) === normContact(c.contact),
            );
            if (!alreadyJoined) {
                await this.bookingModel.updateOne({ _id: booking._id }, { $push: { checkIns: entry }, $addToSet: { attendees: c.name } });
            }
        }

        if (!alreadyJoined) this.gateway.emitBookingsChanged(String(booking.roomId));
        return { result: 'ADMITTED', name: c.name, alreadyJoined, booking: publicInfo };
    }

    // ບັນທຶກການຖືກປະຕິເສດ — ຕັດຊ້ຳ (ຊື່+ເຫດຜົນ) ແລະ ຈຳກັດຈຳນວນ ເພື່ອບໍ່ໃຫ້ຄົນສະແປມເຮັດໃຫ້ເອກະສານໃຫຍ່
    private async logDenied(
        booking: RoomBookingDocument,
        e: { name: string; contact: string; inviteeId?: string; reason: JoinReason; via: Via },
    ) {
        if (!e.name) return;
        const denied = booking.checkIns.filter((c) => c.result === 'DENIED');
        if (denied.length >= MAX_DENIED_LOGS) return;
        if (denied.some((d) => d.reason === e.reason && normName(d.name) === normName(e.name) && normContact(d.contact) === normContact(e.contact))) return;
        await this.bookingModel.updateOne(
            { _id: booking._id },
            { $push: { checkIns: { name: e.name, contact: e.contact || undefined, inviteeId: e.inviteeId, result: 'DENIED', reason: e.reason, via: e.via, at: new Date() } } },
        );
        this.gateway.emitBookingsChanged(String(booking.roomId));
    }
}
