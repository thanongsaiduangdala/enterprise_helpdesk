import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  UploadedFile,
  UseInterceptors,
  UseGuards,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiBody, ApiQuery } from '@nestjs/swagger';
import { AssetsService } from './assets.service';
import { CreateAssetDto } from './dto/create-asset.dto';
import { UpdateAssetDto } from './dto/update-asset.dto';
import { AssignAssetDto } from './dto/assign-asset.dto';
import { AssignDepartmentDto } from './dto/assign-department.dto';
import { ReturnAssetDto } from './dto/return-asset.dto';
import { ClaimAssetDto } from './dto/claim-asset.dto';
import { SetAssetStatusDto } from './dto/set-asset-status.dto';
import { AssetStatus, HolderType } from './schemas/asset.schema';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { PermissionsGuard } from '../common/guards/permissions.guard';
import { RequirePermission } from '../common/decorators/require-permission.decorator';
import { AuditLogsService } from '../audit-logs/audit-logs.service';

@Controller('assets')
@UseGuards(JwtAuthGuard, PermissionsGuard)
@ApiBearerAuth()
export class AssetsController {
  constructor(
    private assetsService: AssetsService,
    private auditLogsService: AuditLogsService,
  ) {}

  @Post()
  @RequirePermission('assets', 'create')
  create(@Body() dto: CreateAssetDto, @Req() req: any) {
    return this.assetsService.create(dto, req.user.userId, req.ip);
  }

  @Post('bulk-import')
  @RequirePermission('assets', 'create')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: { file: { type: 'string', format: 'binary' } },
    },
  })
  bulkImport(@UploadedFile() file: Express.Multer.File, @Req() req: any) {
    if (!file) {
      throw new BadRequestException(
        'No file uploaded — expected a CSV file under field name "file"',
      );
    }
    return this.assetsService
      .bulkImport(file.buffer, req.user.userId, req.ip)
      .then(async (result) => {
        await this.auditLogsService.log(
          req.user.userId,
          'ASSET_BULK_IMPORTED',
          'Asset',
          'bulk',
          undefined,
          {
            total: result.total,
            created: result.created,
            failed: result.failed,
          },
          req.ip,
        );
        return result;
      });
  }

  @Get()
  @RequirePermission('assets', 'read')
  @ApiQuery({ name: 'branchId', required: false })
  @ApiQuery({ name: 'status', required: false, enum: AssetStatus })
  @ApiQuery({ name: 'assigneeId', required: false })
  @ApiQuery({ name: 'departmentId', required: false })
  @ApiQuery({ name: 'holderType', required: false, enum: HolderType })
  @ApiQuery({ name: 'catalogItemId', required: false })
  findAll(
    @Query('branchId') branchId?: string,
    @Query('status') status?: AssetStatus,
    @Query('assigneeId') assigneeId?: string,
    @Query('departmentId') departmentId?: string,
    @Query('holderType') holderType?: HolderType,
    @Query('catalogItemId') catalogItemId?: string,
  ) {
    const ht =
      holderType && Object.values(HolderType).includes(holderType)
        ? holderType
        : undefined;
    return this.assetsService.findAll({
      branchId,
      status,
      assigneeId,
      departmentId,
      holderType: ht,
      catalogItemId,
    });
  }

  @Get('overdue')
  @RequirePermission('assets', 'read')
  findOverdue() {
    return this.assetsService.findOverdueReturns();
  }

  @Get(':id/timeline')
  @RequirePermission('assets', 'read')
  timeline(@Param('id') id: string) {
    return this.assetsService.getTimeline(id);
  }

  @Get(':id')
  @RequirePermission('assets', 'read')
  findOne(@Param('id') id: string) {
    return this.assetsService.findOne(id);
  }

  @Patch(':id')
  @RequirePermission('assets', 'update')
  update(@Param('id') id: string, @Body() dto: UpdateAssetDto) {
    return this.assetsService.update(id, dto);
  }

  @Patch(':id/assign')
  @RequirePermission('assets', 'assign')
  assign(
    @Param('id') id: string,
    @Body() dto: AssignAssetDto,
    @Req() req: any,
  ) {
    return this.assetsService.assign(id, dto, req.user.userId, req.ip);
  }

  @Patch(':id/assign-department')
  @RequirePermission('assets', 'assign')
  assignDepartment(
    @Param('id') id: string,
    @Body() dto: AssignDepartmentDto,
    @Req() req: any,
  ) {
    return this.assetsService.assignToDepartment(
      id,
      dto,
      req.user.userId,
      req.ip,
    );
  }

  @Patch(':id/claim')
  @RequirePermission('assets', 'read')
  claim(@Param('id') id: string, @Body() dto: ClaimAssetDto, @Req() req: any) {
    return this.assetsService.claim(
      id,
      req.user,
      dto.note,
      req.ip,
      dto.assigneeCode,
    );
  }

  @Patch(':id/return')
  @RequirePermission('assets', 'assign')
  returnAsset(
    @Param('id') id: string,
    @Body() dto: ReturnAssetDto,
    @Req() req: any,
  ) {
    return this.assetsService.returnAsset(id, dto, req.user.userId, req.ip);
  }

  @Patch(':id/status')
  @RequirePermission('assets', 'update')
  setStatus(
    @Param('id') id: string,
    @Body() dto: SetAssetStatusDto,
    @Req() req: any,
  ) {
    return this.assetsService.setStatus(
      id,
      dto.status,
      req.user.userId,
      req.ip,
    );
  }

  @Delete(':id')
  @RequirePermission('assets', 'delete')
  remove(@Param('id') id: string, @Req() req: any) {
    return this.assetsService.remove(id, req.user.userId, req.ip);
  }
}