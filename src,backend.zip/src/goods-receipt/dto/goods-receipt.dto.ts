import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  IsArray,
  IsDateString,
  IsEnum,
  IsInt,
  IsNumber,
  Matches,
  MaxLength,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  Min,
  ValidateNested,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class ReceiveCommonDto {
  @ApiProperty({ example: 10, description: 'ຈຳນວນຊິ້ນ (ຈຳນວນເຕັມ ≥ 1)' })
  @Type(() => Number)
  @IsInt({ message: 'ຈຳນວນຕ້ອງເປັນຈຳນວນເຕັມ' })
  @Min(1, { message: 'ຈຳນວນຕ້ອງຢ່າງໜ້ອຍ 1' })
  @Max(1000, { message: 'ຈຳນວນຕໍ່ຄັ້ງຕ້ອງບໍ່ເກີນ 1000' })
  quantity!: number;

  @ApiPropertyOptional({ example: '2026-10-22' })
  @IsOptional()
  @IsDateString({}, { message: 'ວັນທີຮັບບໍ່ຖືກຕ້ອງ' })
  receivedDate?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  vendor?: string;

  @ApiPropertyOptional({ example: 4500000, description: 'ລາຄາຕໍ່ໜ່ວຍ (ກີບ)' })
  @IsOptional()
  @Type(() => Number)
  @IsNumber({}, { message: 'ລາຄາຕໍ່ໜ່ວຍຕ້ອງເປັນຕົວເລກ' })
  @Min(0, { message: 'ລາຄາຕໍ່ໜ່ວຍຕ້ອງບໍ່ຕິດລົບ' })
  unitPrice?: number;

  @ApiPropertyOptional({ example: 'ຫ້ອງເກັບເຄື່ອງ 2' })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  storageRoom?: string;

  @ApiPropertyOptional({ example: 'INV-2026-0123' })
  @IsOptional()
  @IsString()
  @MaxLength(100)
  invoiceNo?: string;

  @ApiPropertyOptional({ description: 'URL ໄຟລ໌ໃບບິນທີ່ອັບໂຫຼດແລ້ວ (/api/uploads/...)' })
  @IsOptional()
  @IsString()
  @Matches(/^\/api\/uploads\/[a-f0-9]{32}(\.[a-z0-9]+)?$/i, {
    message: 'ໄຟລ໌ໃບບິນບໍ່ຖືກຕ້ອງ',
  })
  invoiceFileUrl?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(200)
  invoiceFileName?: string;

  @ApiPropertyOptional({ description: 'ໃບສະເໜີຊື້ (PurchaseRequest _id) ທີ່ອະນຸມັດແລ້ວ' })
  @IsOptional()
  @IsString()
  purchaseRequestId?: string;

  @ApiPropertyOptional({
    description: 'ເຫດຜົນ ເມື່ອຮັບເຄື່ອງໂດຍບໍ່ມີໃບສະເໜີ (ສະເພາະຜູ້ມີສິດພິເສດ)',
  })
  @IsOptional()
  @IsString()
  @MaxLength(500)
  exceptionReason?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  note?: string;

  @ApiPropertyOptional({
    example: 20,
    description: 'ຈຳນວນຕາມໃບສົ່ງເຄື່ອງ (ທາງເລືອກ)',
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt({ message: 'ຈຳນວນຕາມໃບສົ່ງຕ້ອງເປັນຈຳນວນເຕັມ' })
  @Min(1, { message: 'ຈຳນວນຕາມໃບສົ່ງຕ້ອງຢ່າງໜ້ອຍ 1' })
  expectedQuantity?: number;

  @ApiPropertyOptional({
    description: 'ໝາຍເຫດເມື່ອຈຳນວນນັບບໍ່ກົງກັບໃບສົ່ງ',
  })
  @IsOptional()
  @IsString()
  countNote?: string;

  @ApiPropertyOptional({
    example: 'BX001',
    description: 'ສາຂາ / ບ່ອນເກັບ (ຄ່າເລີ່ມຕົ້ນ = ສາຂາຂອງຜູ້ຮັບ)',
  })
  @IsOptional()
  @IsString()
  branchId?: string;

  @ApiPropertyOptional({ type: [String], description: 'ສະເພາະອຸປະກອນ (DEVICE)' })
  @IsOptional()
  @IsArray()
  @ArrayMaxSize(1000)
  @IsString({ each: true })
  serialNumbers?: string[];

  @ApiPropertyOptional({
    example: '2027-10-29',
    description: 'ວັນໝົດປະກັນ — ໃຊ້ກັບທຸກຊິ້ນທີ່ຮັບ (ສະເພາະອຸປະກອນ)',
  })
  @IsOptional()
  @IsDateString({}, { message: 'ວັນໝົດປະກັນບໍ່ຖືກຕ້ອງ' })
  warrantyExpiry?: string;

  @ApiPropertyOptional({
    type: [String],
    description:
      'ວັນໝົດປະກັນຕໍ່ຊິ້ນ ຈັບຄູ່ຕາມລຳດັບ (ຄ່າວ່າງ = ໃຊ້ warrantyExpiry ລວມ)',
  })
  @IsOptional()
  @IsArray()
  @ArrayMaxSize(1000)
  @IsString({ each: true })
  warrantyExpiries?: string[];
}

export class RestockDto extends ReceiveCommonDto {
  @ApiProperty({ example: 'SC001' })
  @IsNotEmpty({ message: 'ກະລຸນາເລືອກລາຍການ' })
  @IsString()
  catalogItemId!: string;
}

export enum NewItemKind {
  /** ຮັກສາໄວ້ເພື່ອຄວາມເຂົ້າກັນໄດ້ກັບ client ເກົ່າ — ເທົ່າກັບ DEVICE_SERIAL */
  DEVICE = 'DEVICE',
  DEVICE_SERIAL = 'DEVICE_SERIAL',
  DEVICE_TAG = 'DEVICE_TAG',
  CONSUMABLE = 'CONSUMABLE',
}

export class NewItemInfoDto {
  @ApiProperty()
  @IsNotEmpty({ message: 'ກະລຸນາໃສ່ຊື່ລາຍການ' })
  @IsString()
  name!: string;

  @ApiProperty()
  @IsNotEmpty({ message: 'ກະລຸນາໃສ່ໝວດໝູ່' })
  @IsString()
  category!: string;

  @ApiProperty()
  @IsNotEmpty({ message: 'ກະລຸນາໃສ່ໜ່ວຍນັບ' })
  @IsString()
  unit!: string;

  @ApiPropertyOptional({ description: 'ຮູບລາຍການ (/api/uploads/...)' })
  @IsOptional()
  @IsString()
  @Matches(/^(\/api\/uploads\/[a-f0-9]{32}\.(png|jpe?g|gif|webp))?$/i, {
    message: 'ຮູບລາຍການບໍ່ຖືກຕ້ອງ (ຮອງຮັບ png, jpg, gif, webp)',
  })
  imageUrl?: string;

  @ApiProperty({ enum: NewItemKind })
  @IsEnum(NewItemKind, {
    message:
      'ປະເພດຕ້ອງເປັນ DEVICE_SERIAL, DEVICE_TAG ຫຼື CONSUMABLE',
  })
  type!: NewItemKind;
}

export class NewItemDto extends ReceiveCommonDto {
  @ApiProperty({ type: NewItemInfoDto })
  @ValidateNested()
  @Type(() => NewItemInfoDto)
  item!: NewItemInfoDto;
}
